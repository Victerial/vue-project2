<script setup>
import Bolt from '@/components/Bolt.vue';
import TheWelcome from '../components/Bolt.vue'
</script>

<template>
  
</template>
