<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
 <div>
    <router-link to="/">Bolt</router-link> |
    <router-link to="/kosar">Kosár</router-link> |
    <router-link to="/uj-termek">Új termék</router-link>
    <router-view></router-view>
  </div>

  <RouterView />
</template>

<style scoped>

</style>
