<template>
    <div>
      <h1>Kosár</h1>
      <div v-for="item in cart" :key="item.id">
        <h4>{{ item.product.name }}</h4>
        <p>Mennyiség: {{ item.quantity }}</p>
        <p>Ár: {{ item.product.price }} Ft</p>
        <button @click="removeFromCart(item.id)" class="btn btn-danger">Törlés</button>
      </div>
      <button @click="placeOrder" class="btn btn-success">Rendelés véglegesítése</button>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        cart: [],
      };
    },
    mounted() {
      axios.get('http://localhost:3000/cart')
        .then(response => {
          this.cart = response.data.map(item => ({
            ...item,
            product: this.getProductById(item.productId),
          }));
        })
        .catch(error => {
          console.log(error);
        });
    },
    methods: {
      getProductById(id) {
        return axios.get(`http://localhost:3000/products/${id}`)
          .then(response => response.data)
          .catch(error => console.log(error));
      },
      removeFromCart(itemId) {
        axios.delete(`http://localhost:3000/cart/${itemId}`)
          .then(() => {
            this.cart = this.cart.filter(item => item.id !== itemId);
            alert('Termék eltávolítva a kosárból!');
          })
          .catch(error => {
            console.log(error);
          });
      },
      placeOrder() {
        const order = {
          id: Date.now().toString(),
          datum: new Date().toISOString().split('T')[0],
          pId: this.cart.map(item => item.productId),
          quantity: this.cart.map(item => item.quantity),
          uId: '1', 
        };
        axios.post('http://localhost:3000/order', order)
          .then(() => {
            this.cart = [];
            alert('Rendelés véglegesítve!');
          })
          .catch(error => {
            console.log(error);
          });
      }
    }
  };
  </script>
  