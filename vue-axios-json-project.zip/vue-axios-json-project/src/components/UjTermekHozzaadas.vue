<template>
    <div>
      <h1>Új termék hozzáadása</h1>
      <form @submit.prevent="addNewProduct">
        <div class="form-group">
          <label for="name">Név:</label>
          <input type="text" id="name" v-model="newProduct.name" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="price">Ár:</label>
          <input type="number" id="price" v-model="newProduct.price" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="img">Kép URL:</label>
          <input type="text" id="img" v-model="newProduct.img" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Hozzáadás</button>
      </form>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        newProduct: {
          name: '',
          price: null,
          img: ''
        }
      };
    },
    methods: {
      addNewProduct() {
        axios.post('http://localhost:3000/products', this.newProduct)
          .then(response => {
            alert('Új termék hozzáadva!');
            this.$router.push('/');
          })
          .catch(error => {
            console.log(error);
          });
      }
    }
  };
  </script>
  