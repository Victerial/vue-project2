<template>
    <h1>Bolt</h1>
    <div>
        <div v-for="product in products" :key="product.id" class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" :alt="product.name" />
          <div class="card-body">
            <h4 class="card-title">{{ product.name }}</h4>
            <p class="card-text">Ár: {{ product.price }} Ft</p>
            <button @click="addToCart(product)" class="btn btn-primary">
              Kosárba
            </button>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import {ref, onMounted} from 'vue';
  import axios from 'axios';

  onMounted(() => {
    axios.get('http://localhost:3000/products')
      .then(resp => console.log(resp.data));
  },
  methods: {
    addToCart(product) {
      const cartItem = {
        id: Date.now().toString(),
        productId: product.id,
        quantity: 1,
      };
      axios.post('http://localhost:3000/cart', cartItem)
        .then(() => {
          alert('Termék hozzáadva a kosárhoz!');
        });
    }
  })
  </script>
  